﻿namespace PortfolioBlazor.Helpers
{
    public class WordDistance
    {
        public string Word;
        public int Distance;
    }
}
