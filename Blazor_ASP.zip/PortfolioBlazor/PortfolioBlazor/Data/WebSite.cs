﻿using ClassWithParameters;
namespace PortfolioBlazor.Data
{
    public class WebSite
    {
        public ListOfUsers list;
        public WebSite() {

            list = new ListOfUsers();

        }
    }
}
